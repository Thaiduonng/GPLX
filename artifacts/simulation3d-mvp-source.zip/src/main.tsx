import { useEffect, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import Simulation3D from './features/simulation3d/ui/Simulation3D';
import { validateRules } from './features/simulation3d/rules/configuration';
import type { RuleSet } from './features/simulation3d/types';
import './standalone.css';
function App(){
 const [rules,setRules]=useState<RuleSet|null>(null);const [error,setError]=useState('');const [retry,setRetry]=useState(0);
 useEffect(()=>{const c=new AbortController();setError('');fetch('/simulation3d/rules-2026-10.json',{signal:c.signal}).then(r=>{if(!r.ok)throw new Error('Không tải được quy tắc.');return r.json();}).then((r:unknown)=>setRules(validateRules(r))).catch(e=>{if(!c.signal.aborted)setError(e instanceof Error?e.message:'Lỗi tải cấu hình.');});return()=>c.abort();},[retry]);
 if(error)return <main role="alert"><h1>Không tải được sân</h1><p>{error}</p><button onClick={()=>setRetry(n=>n+1)}>Thử lại</button></main>;
 return rules?<Simulation3D rules={rules} ownerId={0} showLegacy={false}/>:<p role="status">Đang tải sân 3D…</p>;
}
createRoot(document.getElementById('root')!).render(<BrowserRouter><App/></BrowserRouter>);
